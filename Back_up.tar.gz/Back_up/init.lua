-- file : init.lua
app = require("applications")  
config = require("config")  
setup = require("setup")

setup.start()  
