LuaSrcDiet is distributed under MIT license.
See COPYRIGHT_LuaSrcDiet for licensing info.

CAUTION: This version of LuaSrcDiet requires Lua 5.1 and will NOT work under Lua 5.2!
