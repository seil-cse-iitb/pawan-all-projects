﻿******************************************************************************
*                                                                            *
*                             ESPresso v.0.3.0.0                             *
*                     (c) 2016-2017 by Łukasz Cielecki                       *
*                                                                            *
******************************************************************************

ESPresso is a free software provided by Łukasz Cielecki which may be freely 
distributed, provided that no charge above the cost of distribution is levied,
and that the disclaimer below is always attached to it.

The program is provided as is without any guarantees or warranty.

Although the author has attempted to find and correct any bugs in the free
software program, the author is not responsible for any damage or losses
of any kind caused by the use or misuse of the program.

The author is under no obligation to provide support, service, corrections,
or upgrades to the free software programs.

ESPresso uses ueControls components which are distributed under Mozilla Public
License Version 1.1 (MPL). You may obtain a copy of the MPL License at
http://www.mozilla.org/MPL/MPL-1.1.html

ESPresso uses BGRABitmap library which is distributed under modified LGPL
license. See https://sourceforge.net/projects/lazpaint/files/src/ for
more details.

ESPresso uses Eye Candy Controls components which is distributed under modified
LGPL license. See https://sourceforge.net/projects/eccontrols/ for more 
details.

ESPresso uses SynEdit component which is distributed under Mozilla Public
License Version 1.1 (MPL). See https://sourceforge.net/projects/synedit/ for
more details.

ESPresso uses Lua Script highlighter for SynEdit created by Zhou Kan which is
distributed under Mozilla Public License Version 1.1 (MPL). You may obtain 
a copy of the MPL License at http://www.mozilla.org/MPL/MPL-1.1.html

This software package contains LuaSrcDiet which is distributed under MIT
license. See lua subdirectory for details.

This software package contains Lua 5.1 which is distributed under MIT
license. See lua subdirectory for details.

This software package contains ESP telnet script which is distributed under MIT
license. See ESP subdirectory for details.

******************************************************************************
* Changelog:
******************************************************************************

v.0.1.0.0 (2016-07-29)
- Initial release
v.0.1.1.0 (2016-08-09)
* Fixed some code portability issues
- Initial Linux release
v.0.2.0.0 (2016-12-09)
- New binary transfer mode that provides 100% carbon copy of source file 
  on ESP side
- Redesigned LuaSrcDiet compression. Now it uses interpreted script along with
  Lua interpreter.
- Source file preview with Lua syntax highlighting
- Some user interface bugfixes and improvements
v.0.3.0.0 (2017-02-05)
* Fixed directory listing bug that might have caused some files to be missing
  on the first directory listing after connect
- New rename dialog box that works under Linux
- Some user interface bugfixes and improvements - more keyboard shortcuts
- Added possibility to pass optional parameters to LuaSrcDiet

******************************************************************************
* Introduction
******************************************************************************

ESPresso is an ESP8266 file manager and uploader with some distinct features:
- It connects to ESP directly over TCP/IP port (in other words - over WiFi).
  It's not using any serial port (physical nor virtual). No additional software
  on computer side is required. The only thing you need is to run the daemon 
  script on the ESP side (standard script from NodeMCU docs that redirects 
  serial output to TCP - see below for details).
- It represents a two pane filemanager approach. It's designed to effectively
  send files to ESP, compile them and run.
- It can 'diet' uploaded files using 'LuaSrcDiet' on the fly.
- It's equipped with a built-in ADC monitor with simple graph.
- It's possible to preview source Lua files in built-in viewer with Lua 
  source higligther.

******************************************************************************
* Requirements
******************************************************************************

1. A computer. Binaries for Windows (both 32 or 64 bit) and Linux (64 bit, gtk2)
   are provided.
2. An ESP8266 working under NodeMCU (the newer the better). You need to run
   'telnet' script. You may use the one from NodeMCU examples
   [https://github.com/nodemcu/nodemcu-firmware/blob/master/lua_examples/telnet.lua]
   (also included in this distribution in ESP directory) or use your own (it
   should simply redirect all serial output to TCP socket and grab all the data
   from the socket and send it to the NodeMCU interpreter). CAUTION: Telnet
   script from old NodeMCU docs which was copied to many websites is NOT
   working properly with new NodeMCU versions. Use the one from Github.

Depending on the way your ESP application is using TCP connection there are
different ways to embed the telnet script in your software:
1. Your app is not using any form of communication. In this case the only thing
   you need is to put:
   dofile('telnet.lua')
   somewhere in you 'init.lua' file. Since there is no other communication it
   will not interfere with it.
2. Your app acts as a client (it does NOT create a server) - it opens outgoing
   connections. Such a situation doesn't require much attention. Tests showed
   that even when telnet session to ESP is active, outgoing connections are not
   interfered. However it may be good idea to disable your app normal operation
   (that involves using TCP connections) during file sending with ESPresso.
   Good place to do this is the beginning of the callback function registered
   in net.server:listen() in telnet.lua. Regular operation mode of your app may
   be restored in callback for socket:on("disconnection").
3. Your app is a webserver. Unfortunately it's not possible to start more than
   a single server listening on a single port in NodeMCU, therefore it's not
   possible for an app to operate and wait for a telnet session simultaneously.
   However - it doesn't mean that there is nothing you can do:
   a. You may design a 'service mode' of your ESP8266 device. It may be
      triggered by a special switch or combination of regular buttons. If in 
      service mode your app would start telnet server instead of regular one.
   b. Another option is to develop a server that recognizes if a regular or
      telnet connection is coming by analysing some of the very first
      characters received from socket. Depending of the content received it
      would pass the payload to the proper function.
   Both options require individual approach that fits to your application.

******************************************************************************
* Instructions manual
******************************************************************************

1. ESPresso doesn't require installation. Just unzip files to the location you
   want and run the 'espresso.exe' (win32, win64) or 'espresso' (Linux 
   version). Make sure that your firewall doesn't block outgoing connections. 
   If you don't know which version to use - choose win32. ESPresso requires 
   Visual C++ Redistributable for Visual Studio 2012 to be present on your 
   system. It's likely that it's already installed since many programs depend 
   on it. If your system shows that MSVCR110.dll is missing when you start 
   ESPresso then you might use the MSVCR110.dll file included in win32 version
   folder or install proper version of VCredist from:
   https://www.microsoft.com/en-au/download/details.aspx?id=30679
2. Enter Address and Port of your ESP. Make sure that 'telnet.lua' is running
   on your ESP (you have to upload it over serial port first). Hit 'Connect'.
3. After successful connect a list of files on the ESP is updated in the right
   pane.
4. You can do, compile, delete [keyboard shortcuts: F8 or Del] or rename files
   on the ESP using buttons under right pane. When renaming a file that has
   corresponding lc or lua file (with the same name and the other extension)
   it is also possible to rename both files at the same time using 'Rename with
   corresponding file' button in the rename dialog box.
5. Navigate to the directory you want in the left pane to upload files. Only
   *.lua files and directories are shown in the left pane. You may view
   content of your Lua files in the left pane by highlighting them and pressing
   [F3] (or hitting 'View' button).
6. Select file you want to send and hit "Upload" [F5] or "Upload as..." [F6]
   (and enter the destination filename).
7. If you put 'LuaSrcDiet' script and Lua interpreter in lua subfolder than you
   can turn on the 'Diet' switch which will pass all the files you send through
   'LuaSrcDiet'. If you have these files in another directory update paths in
   'ESPresso.ini' file under [DIET]/path and [LUA]/path sections. It's also
   possible to pass additional parameters to LuaSrcDiet by entering them under
   [DIET]/options section of 'ESPresso.ini'.
   Standard ESPresso package has 'LuaSrcDiet.lua' (Windows and Linux) and Lua
   interpreter (Windows only) already included.
8. You can execute any command on the ESP by entering it in the command line at
   the bottom of the window and hitting enter or pushing 'Send' button.
9. You can monitor ADC input of ESP. When connection is established press 'ADC'
   above the right pane. In the new window enter monitoring period and press
   'Enable' to start monitoring.

******************************************************************************
* Feedback
******************************************************************************

This software was written as a commodity for my ESP project. I've got some
ideas for its further development so if you like ESPresso just let me know to
encourage me to keep working on it.

E-mail: lukasz AT cielecki DOT pl

Wrocław, Poland, June 2016 - February 2017

####__     __ Łukasz "MrLuck"_Cielecki     __        __    _    ___  __ #
###/ /_ __/ /_____ _______ /  \ ____(_)__ / /__ ____/ /__ (_)  / _ \/ /##
##/ / // /  '_/ _ `(_-<_ /| (|// __/ / -_) / -_) __/  '_// /  / .__/ /###
#/_/\_,_/_/\_\\_,_/___/__/ \__ \__/_/\__/_/\__/\__/_/\_\/_(_)/_/  /_/####
