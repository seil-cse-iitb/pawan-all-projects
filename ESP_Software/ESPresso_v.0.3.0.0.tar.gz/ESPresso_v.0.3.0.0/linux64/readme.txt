Linux x64 version. Requires gtk2.
