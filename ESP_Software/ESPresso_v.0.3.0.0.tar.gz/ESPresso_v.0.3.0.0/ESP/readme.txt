This is the file that needs to be run on the ESP side. Taken from:
https://github.com/nodemcu/nodemcu-firmware/blob/master/lua_examples/telnet.lua
See LICENSE for copywright info.
