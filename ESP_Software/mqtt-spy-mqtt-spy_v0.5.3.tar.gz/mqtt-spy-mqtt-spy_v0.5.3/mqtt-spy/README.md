The following files use non-EPL/EDP licensing:

    * LineChartPaneController.java	(origin: JFXUtils; Apache License Version 2.0)
    * CommandLinksDialog 			(origin: ControlsFX; BSD 3-Clause License)

The following documents the origin of all graphics (images/icons) used in mqtt-spy. All can be found in src/main/resources/images.
    
MQTT.org

	* mqtt-icon.png
     
Authored by Kamil Baczkowicz:

    * mqtt-spy-logo.png