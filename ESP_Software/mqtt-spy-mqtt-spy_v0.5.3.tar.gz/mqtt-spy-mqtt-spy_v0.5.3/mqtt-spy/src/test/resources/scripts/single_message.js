mqttspy.publish("mqtt-spy/script/test3/", "hello :)", 0, false);

