package pl.baczkowicz.spy.ui.controllers;

public interface IConnectionController
{
	void updateConnectionStats();
}
