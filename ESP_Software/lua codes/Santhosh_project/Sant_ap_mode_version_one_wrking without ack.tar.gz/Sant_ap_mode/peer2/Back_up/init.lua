-- file : init.lua


app = require("client")  
config = require("config")  
setup = require("setup")

setup.start()  
