import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
#from config import MQTT_TOPIC, MQTT_HOST, MQTT_PORT, MQTT_CLIENT
from csv import writer
import time
import datetime as dt

FILE_NAME = 'data_recived.csv'

MQTT_TOPIC = 'nodemcu/+/msg'
MQTT_HOST = '10.129.23.43'
MQTT_PORT = 1883
MQTT_CLIENT = 'san_nodemcu_temperature_data_collector'

def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    client.subscribe(MQTT_TOPIC, qos=2)


def on_message(client, userdata, msg):
    received_msg_topic = msg.topic
    now_dt = dt.datetime.now()
    str_time = dt.datetime.strftime(now_dt, '%Y-%m-%d %H:%M:%S')
    print '%s %s:%s %d' %(now_dt, received_msg_topic, msg.payload, len(msg.payload))
    print type (msg.payload)
    flag=0   
    ack_seq_no = msg.payload[0:6]
    try:
         tobesend=int(ack_seq_no);
    except ValueError:
         print("OOPS ERROR")
         flag=1

    print received_msg_topic
    if(flag==0):
	if(tobesend>=0):
	    	if(received_msg_topic=="nodemcu/peer1/msg"):
	    	    print "this is peer 1 "
		    print tobesend 
	   	    publish.single("nodemcu/peer1/ack", "P1"+ack_seq_no, qos=2)
		    print("This is seq_ack"+ack_seq_no)
	 	if(received_msg_topic=="nodemcu/peer2/msg"):
			print "this is peer 2" 
			publish.single("nodemcu/peer2/ack", "P2"+ack_seq_no , qos=2)
	    		print("This is seq_ack"+ack_seq_no)
    code_file_writer.writerow([int(time.time()),received_msg_topic,msg.payload])
    code_file.flush()

client = mqtt.Client(MQTT_CLIENT+'CSV')
client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_HOST, MQTT_PORT, 60)
code_file = open(FILE_NAME,'ab')
code_file_writer = writer(code_file)
code_file_writer.writerow(['timestamp','topic','code'])
client.loop_forever()
