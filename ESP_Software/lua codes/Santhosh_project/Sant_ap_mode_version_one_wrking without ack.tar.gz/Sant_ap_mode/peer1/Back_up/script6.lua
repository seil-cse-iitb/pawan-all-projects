ledOn = 0
pin=4
gpio.mode(pin,gpio.OUTPUT)
uart.on("data", 8, 
    function(data)
        print("Received from Arduino:", data)
        if data=="HI!" then
            if ledOn==0 then
                ledOn = 1
                gpio.write(pin,gpio.HIGH)
                print("LED On")
            else
                ledOn = 0
                gpio.write(pin,gpio.LOW)
                print("LED Off")
        end        
    end        
end, 0)