app = require("aspta")  
config = require("config")  
setup = require("setup")

setup.start()  
