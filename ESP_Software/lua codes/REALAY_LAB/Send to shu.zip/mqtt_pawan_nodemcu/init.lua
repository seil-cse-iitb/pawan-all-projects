-- file : init.lua
app = require("application")  
config = require("config")  
setup = require("setup")

setup.start()  
