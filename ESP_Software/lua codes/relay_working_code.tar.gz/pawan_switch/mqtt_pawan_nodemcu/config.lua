-- file : config.lua
local module = {}

module.SSID = {}  
module.SSID["SEIL"] = "deadlock123"

module.HOST = "10.129.23.30"  
module.PORT = 1883
module.ID = "101"

module.ENDPOINT = "CONTROL/LHC/RELAY/"  
return module 
