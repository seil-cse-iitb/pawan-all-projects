-- file : application.lua
local module = {}  
m = nil

relay1 = 1
relay2 = 2
relay3 = 3
relay4 = 4
relay5 = 5
relay6 = 6
relay7 = 7
relay8 = 8

relay_state = false

gpio.mode(relay1, gpio.OUTPUT)
gpio.mode(relay2, gpio.OUTPUT)
gpio.mode(relay3, gpio.OUTPUT)
gpio.mode(relay4, gpio.OUTPUT)
gpio.mode(relay5, gpio.OUTPUT)
gpio.mode(relay6, gpio.OUTPUT)
gpio.mode(relay7, gpio.OUTPUT)
gpio.mode(relay8, gpio.OUTPUT)


local function set_relay(relay_no,state)
    print("upcoming")
    print(relay_no)
    print(state)
    relay_state = state
    if state == false then
        gpio.write(relay_no,gpio.HIGH )
        print("state false");
    else
        gpio.write(relay_no, gpio.LOW)
        print("state true");
    end
end

-- Sends a simple ping to the broker
local function send_ping()  
   -- m:publish(config.ENDPOINT .. "ping","id=" .. config.ID,0,0)
  --  m:publish(config.ENDPOINT .. "temp","temp=100",0,0)
end

-- Sends my id to the broker for registration
local function register_myself()  
    m:subscribe(config.ENDPOINT .. config.ID,0,function(conn)
       
        print("Successfully subscribed to data endpoint"..config.ENDPOINT .. config.ID)
    end)
end

local function mqtt_start()  
    m = mqtt.Client(config.ID, 120)
    -- register message callback beforehand
    m:on("message", function(conn, topic, data) 
    print(topic .. ": " ..data)
    temp="123456"
    print(type(data)..type(temp));
    print(string.byte(temp,2));
    objProp = {}
    index = 1
    for value in string.gmatch(data,"%w+") do 
    objProp [index] = value
    index = index + 1
    end
    
    relay_no=objProp[1]
    if(objProp[2]=='1') then
       relay_state=true;
       else
       relay_state=false;
       end

    set_relay(relay_no,relay_state)

    
  --   if data == "1" then
   --     print(topic .. ": " .. data)
         -- if data == "on1" then
     --          print("turning on");
      --         set_relay(true);
       -- 
        -- do something, we have received a message
  --    end
  --  if data == "off1" then
    --    print(topic .. ": " .. data)
         -- if data == "on1" then
        --       print("turning off");
      --         set_relay(false);
       -- 
        -- do something, we have received a message
     -- end

      
    end)
    -- Connect to broker
    m:connect(config.HOST, config.PORT, 0, 1, function(con) 
        register_myself()
        -- And then pings each 1000 milliseconds
        tmr.stop(6)
        tmr.alarm(6, 1000, 1, send_ping)
    end) 

end

--local function recv_cmd()  
 --   m:subscribe(config.ENDPOINT .. "cmd",0,function(conn) print("subscribe sucess") end)
  --  m:publish(config.ENDPOINT .. "temp","temp=100",0,0)
--end


function module.start()  
  mqtt_start()
end

return module  
