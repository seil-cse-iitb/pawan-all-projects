app = require("appa")  
config = require("config")  
setup = require("setup")

setup.start()  
