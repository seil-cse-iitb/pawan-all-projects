dofile("doConnect.lc")();
print("starting heap="..node.heap())
dofile("uart.lc")
dofile("main.lc")
